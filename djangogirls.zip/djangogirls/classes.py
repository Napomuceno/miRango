# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class Categoria(models.Model):
    desc_tipocat = models.CharField(max_length=100, blank=True, null=True)
    cod_tipocat = models.IntegerField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'categoria'


class Comprar(models.Model):
    fk_pessoa_cod_pessoa = models.ForeignKey('Pessoa', models.DO_NOTHING, db_column='fk_pessoa_cod_pessoa', blank=True, null=True)
    fk_menu_cod_menu = models.ForeignKey('Menu', models.DO_NOTHING, db_column='fk_menu_cod_menu', blank=True, null=True)
    valorcompr = models.FloatField(blank=True, null=True)
    descpag = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'comprar'


class Contato(models.Model):
    cod_contat = models.IntegerField(primary_key=True)
    desc_contat = models.CharField(max_length=100, blank=True, null=True)
    fk_pessoa_cod_pessoa = models.ForeignKey('Pessoa', models.DO_NOTHING, db_column='fk_pessoa_cod_pessoa', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'contato'


class Estabelecimento(models.Model):
    cod_estab = models.IntegerField(primary_key=True)
    desc_estab = models.CharField(max_length=100, blank=True, null=True)
    fk_pessoa_cod_pessoa = models.ForeignKey('Pessoa', models.DO_NOTHING, db_column='fk_pessoa_cod_pessoa', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'estabelecimento'


class ItenProduto(models.Model):
    cod_itemprod = models.IntegerField(primary_key=True)
    desc_iten_produto = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'iten_produto'


class Menu(models.Model):
    cod_menu = models.IntegerField(primary_key=True)
    fk_pessoa_cod_pessoa = models.ForeignKey('Pessoa', models.DO_NOTHING, db_column='fk_pessoa_cod_pessoa', blank=True, null=True)
    fk_produto_cod_prod = models.ForeignKey('Produto', models.DO_NOTHING, db_column='fk_produto_cod_prod', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'menu'


class Pessoa(models.Model):
    nome_comp = models.CharField(max_length=100, blank=True, null=True)
    senha = models.CharField(max_length=10, blank=True, null=True)
    cod_pessoa = models.IntegerField(primary_key=True)
    data_nasc = models.DateField(blank=True, null=True)
    cnpj = models.IntegerField(blank=True, null=True)
    cpf = models.IntegerField(blank=True, null=True)
    pessoa_tipo = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pessoa'


class Possui2(models.Model):
    fk_contato_cod_contat = models.ForeignKey(Contato, models.DO_NOTHING, db_column='fk_contato_cod_contat', blank=True, null=True)
    fk_tipo_contato_cod_tipocontat = models.ForeignKey('TipoContato', models.DO_NOTHING, db_column='fk_tipo_contato_cod_tipocontat', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'possui2'


class Produto(models.Model):
    desc_produto = models.CharField(max_length=100, blank=True, null=True)
    cod_prod = models.IntegerField(primary_key=True)
    preço = models.IntegerField(blank=True, null=True)
    fk_categoria_cod_tipocat = models.ForeignKey(Categoria, models.DO_NOTHING, db_column='fk_categoria_cod_tipocat', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'produto'


class Relacionamento2(models.Model):
    fk_produto_cod_prod = models.ForeignKey(Produto, models.DO_NOTHING, db_column='fk_produto_cod_prod', blank=True, null=True)
    fk_iten_produto_cod_itemprod = models.ForeignKey(ItenProduto, models.DO_NOTHING, db_column='fk_iten_produto_cod_itemprod', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'relacionamento_2'


class TipoContato(models.Model):
    cod_tipocontat = models.IntegerField(primary_key=True)
    desc_tipocontat = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tipo_contato'
