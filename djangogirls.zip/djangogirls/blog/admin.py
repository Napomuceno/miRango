from django.contrib import admin
from .models import Categoria,Comprar,Contato,Estabelecimento,Ingrediente,Menu,Pessoa,Produto,TipoContato

# Register your models here.
admin.site.register(Categoria)
admin.site.register(Comprar)
admin.site.register(Contato)
admin.site.register(Estabelecimento)
admin.site.register(Ingrediente)
admin.site.register(Menu)
admin.site.register(Pessoa)
admin.site.register(Produto)
admin.site.register(TipoContato)

