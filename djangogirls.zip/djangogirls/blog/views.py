from django.shortcuts import render
from django.utils import timezone
from .models import Produto



def post_list(request):
    desc_produto = Produto.objects.all()
    var_get_search = request.GET.get('search_box')
    if var_get_search is not None:
       desc_produto = desc_produto.filter(desc_produto__icontains =var_get_search)
    context = {'desc_produto': desc_produto}
    return render(request, 'blog/resultp.html', context)



