from __future__ import unicode_literals
from django.db import models
from django.utils import timezone

class Categoria(models.Model):
    descricao = models.CharField(max_length=100)
    def __str__(self):
        return self.descricao


class Comprar(models.Model):
    pessoa = models.ForeignKey('Pessoa')
    menu = models.ForeignKey('Menu')
    valor = models.FloatField()
    descricao = models.CharField(max_length=100)


class TipoContato(models.Model):
    descricao = models.CharField(max_length=100, blank=True, null=True)


class Contato(models.Model):
    descricao = models.CharField(max_length=100, blank=True, null=True)
    pessoa= models.ForeignKey('Pessoa')
    tipo_contato = models.ForeignKey('TipoContato')


class Estabelecimento(models.Model):
    descricao = models.CharField(max_length=100)
    pessoa = models.ForeignKey('Pessoa')


class Ingrediente(models.Model):
    descricao = models.CharField(max_length=100)

    def __str__(self):
        return self.descricao


class Menu(models.Model):
    pessoa = models.ForeignKey('Pessoa')
    produto = models.ForeignKey('Produto')


class Pessoa(models.Model):
    nome = models.CharField(max_length=100, blank=True, null=True)
    senha = models.CharField(max_length=10, blank=True, null=True)
    data_nasc = models.DateField(blank=True, null=True)
    cnpj = models.IntegerField(blank=True, null=True)
    cpf = models.IntegerField(blank=True, null=True)
    pessoa_tipo = models.IntegerField(blank=True, null=True)

class Produto(models.Model):
    desc_produto = models.CharField(max_length=100, blank=True, null=True)
    cod_prod = models.IntegerField(primary_key=True)
    preço = models.IntegerField(blank=True, null=True)
    categoria = models.ForeignKey('Categoria')
    ingredientes = models.ManyToManyField('Ingrediente')



    def __str__(self):
        return self.desc_produto




    
